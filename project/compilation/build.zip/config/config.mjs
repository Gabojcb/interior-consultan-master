export default {"package":"project","version":"0.0.1","languages":{"default":"en","supported":["en","es"]},"global.css":true,"params":{},"ssr":{},"backend":{}};
