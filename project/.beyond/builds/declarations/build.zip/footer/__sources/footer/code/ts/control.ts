import { PageReactWidgetController } from "@beyond-js/react-18-widgets/page";
import { Footer } from "./view";

export /*bundle*/
class Controller extends PageReactWidgetController {
  get Widget() {
    return Footer;
  }
}
