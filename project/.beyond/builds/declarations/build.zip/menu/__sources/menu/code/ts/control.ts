export /*bundle*/
class Control {

    constructor() {

    }

}